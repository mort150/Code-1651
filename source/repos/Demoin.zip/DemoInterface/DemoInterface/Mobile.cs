﻿using System;
namespace DemoInterface
{
    public class Mobile
    {
        protected string name;
        public Mobile()
        {
        }
    }
}
