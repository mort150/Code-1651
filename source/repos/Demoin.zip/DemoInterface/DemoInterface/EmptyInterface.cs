﻿using System;
namespace DemoInterface
{
    public interface ICharger
    {
        public abstract void charge();
    }
}
