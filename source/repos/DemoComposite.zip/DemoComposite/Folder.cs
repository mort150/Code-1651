﻿using System;
using System.Collections.Generic;

namespace DemoComposite
{
    public class Folder : LinuxFile
    {
        private List<LinuxFile> children;

        public Folder()
        {
            children = new List<LinuxFile>();
        }

        public Folder(int id, string name) : base(id, name)
        {
            children = new List<LinuxFile>();
        }

        public void Add(LinuxFile f)
        {
            children.Add(f);
        }

        public void Remove(LinuxFile f)
        {
            children.Remove(f);
        }

        public LinuxFile Get(int id)
        {
            foreach(LinuxFile f in children)
            {
                if (f.ID == id) return f;
            }

            foreach(LinuxFile f in children)
            {
                if (f is Folder)
                {
                    LinuxFile found = ((Folder)f).Get(id);
                    if (found != null) return found;
                }
            }

            return null;
        }

        public override void ShowInfo(int level)
        {
            for (int i = 0; i < level; i++) Console.Write("\t");
            Console.WriteLine("drwxrw-rw- " + ID + " " + Name);

            foreach (LinuxFile f in children)
            {
                f.ShowInfo(level + 1);
            }
        }
    }
}
